declare module 'connect-livereload' {
  function connectLivereload(options?: any): any;
  module connectLivereload {}
  export = connectLivereload;
}
